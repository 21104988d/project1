# Deploying the NEAR FeeManager Contract

Deploying a smart contract to the NEAR blockchain involves using the `near-cli`. This guide assumes you have the NEAR CLI installed and configured.

### 1. Install Rust and wasm32 Target

If you haven't already, install Rust and add the `wasm32-unknown-unknown` target, which is required for compiling smart contracts for the NEAR VM.

```bash
# Install rustup (if you don't have it)
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh

# Add the wasm32 target
rustup target add wasm32-unknown-unknown
```

### 2. Build the Smart Contract

Navigate to the `contracts/near` directory and run the build command. This will compile your Rust code into a WebAssembly (`.wasm`) file.

```bash
cd contracts/near
cargo build --target wasm32-unknown-unknown --release
```

Your compiled contract will be located at `target/wasm32-unknown-unknown/release/near_fee_manager.wasm`.

### 3. Deploy the Contract using NEAR CLI

You need a NEAR account to deploy the contract to. For this example, let's assume your account is `your-account.testnet`.

```bash
# Login to your NEAR account (this will open a browser window)
near login

# Deploy the contract to your account
# Replace 'your-account.testnet' with your actual account ID
near deploy --accountId your-account.testnet --wasmFile target/wasm32-unknown-unknown/release/near_fee_manager.wasm
```

### 4. Initialize the Contract

After deploying the code, you must initialize the contract's state by calling the `new` function and setting the owner.

- `FEE_CONTRACT_ACCOUNT`: The account you deployed to (e.g., `your-account.testnet`).
- `OWNER_ACCOUNT`: The account that should have permission to withdraw fees (e.g., `your-main-account.testnet`).

```bash
# Call the 'new' function to initialize the contract
near call FEE_CONTRACT_ACCOUNT new '{"owner_id": "OWNER_ACCOUNT"}' --accountId FEE_CONTRACT_ACCOUNT
```

### 5. Update Your dApp Configuration

Once deployed and initialized, take the `FEE_CONTRACT_ACCOUNT` (e.g., `your-account.testnet`) and add it to the `FEE_MANAGER_CONTRACT_ADDRESSES` map in your dApp's `config.ts` file under the `'near'` key.
