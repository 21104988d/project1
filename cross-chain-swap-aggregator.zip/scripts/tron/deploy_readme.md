# Deploying the Tron FeeManager Contract

Deploying a Solidity smart contract to the Tron network is similar to EVM chains but uses a different toolset. The most common tools are **TronLink (for browsers)**, **TronBox**, or the **Tron-IDE**.

### Using Tron-IDE (Recommended for Simplicity)

1.  **Go to Tron-IDE**: Visit the [Tron-IDE website](https://tronide.io/).
2.  **Import Contract**: Copy the code from `contracts/tron/FeeManager.sol` and paste it into a new file in the IDE.
3.  **Compile**:
    -   Go to the "Compile" tab on the left.
    -   Select the correct compiler version (e.g., `0.8.20` or higher).
    -   Click the "Compile" button.
4.  **Deploy**:
    -   Go to the "Deploy" tab.
    -   **Connect TronLink**: Make sure you have the TronLink browser extension installed and are logged into the account you want to deploy with. Connect it to the IDE. You will need TRX for energy and bandwidth (gas).
    -   Select your compiled `FeeManager` contract from the dropdown.
    -   Click the "Deploy" button.
5.  **Confirm Transaction**: A TronLink pop-up will appear asking you to confirm the deployment transaction. Sign and confirm it.

### After Deployment

Once the transaction is confirmed, the Tron-IDE will show you the deployed **Contract Address**.

### Update Your dApp Configuration

Take this new Tron contract address and add it to the `FEE_MANAGER_CONTRACT_ADDRESSES` map in your dApp's `config.ts` file under the `'tron'` key.
