# Deploying the Sui FeeManager Contract

Deploying a smart contract (called a "Move module") to the Sui network is done using the Sui CLI.

### 1. Install Prerequisites

- **Sui CLI**: Follow the official guide to [install the Sui binaries](https://docs.sui.io/guides/developer/getting-started/sui-install).

### 2. Configure the Sui CLI

Set up a client environment and switch to the desired network (`devnet`, `testnet`, or `mainnet`).

```bash
# Create a new client environment if you don't have one
sui client new-env

# Switch to the network you want to deploy to (e.g., devnet)
sui client switch --env devnet
```

Make sure you have an active address with SUI tokens for gas fees.
```bash
# View your active address
sui client active-address

# Get devnet SUI tokens from the faucet
sui client faucet
```

### 3. Publish the Module

Navigate to the `contracts/sui` directory and run the `sui client publish` command. This command compiles and deploys your module in a single step.

```bash
cd contracts/sui
sui client publish --gas-budget 50000000
```

The CLI will output the transaction details upon successful publication. The most important pieces of information are:
- **Package ID**: The address of your deployed module package.
- **`FeeVault` Object ID**: The ID of the shared `FeeVault` object that was created by the `init` function.
- **`OwnerCap` Object ID**: The ID of the ownership capability object, which will be in your wallet.

### 4. Update Your dApp Configuration

Take the **`FeeVault` Object ID** from the deployment output and add it to the `FEE_MANAGER_CONTRACT_ADDRESSES` map in your dApp's `config.ts` file under the `'sui'` key. Your dApp will interact with this shared object to deposit and withdraw fees.
