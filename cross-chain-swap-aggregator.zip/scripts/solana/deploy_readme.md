# Deploying the Solana FeeManager Contract

Deploying a Solana program built with Anchor requires the Solana Tool Suite and the Anchor CLI.

### 1. Install Prerequisites

- **Solana Tool Suite**: [Install Guide](https://docs.solana.com/cli/install)
- **Anchor CLI**: [Install Guide](https://www.anchor-lang.com/docs/installation)

### 2. Build the Program

Navigate to the `contracts/solana/fee_manager` directory and run the `anchor build` command. This will compile the Rust code and generate the program's IDL (Interface Definition Language).

```bash
cd contracts/solana/fee_manager
anchor build
```

The compiled program will be located at `target/deploy/fee_manager.so`. A new keypair for the program will also be generated at `target/deploy/fee_manager-keypair.json`.

### 3. Configure Solana CLI

Set your Solana CLI to point to the desired cluster (e.g., `devnet`, `testnet`, or `mainnet-beta`).

```bash
# Example for Devnet
solana config set --url https://api.devnet.solana.com
solana config set --keypair /path/to/your/wallet-keypair.json
```

### 4. Deploy the Program

Use the `anchor deploy` command to deploy the program to the configured cluster.

```bash
anchor deploy
```

After a successful deployment, the command will output the **Program ID**. This is the public key of your deployed program.

### 5. Initialize the Fee Vault

The program itself is stateless; you need to create an instance of the `FeeVault` account. This is typically done via a client-side script or transaction, but can also be done via the Anchor CLI for testing.

First, find your Program ID from the deployment step or by running:
```bash
anchor keys list
```

You will need to write a simple client-side script using `@solana/web3.js` and `@coral-xyz/anchor` to call the `initialize` instruction. This will create the `feeVault` account and set its owner.

### 6. Update Your dApp Configuration

Once you have the public key for your initialized `feeVault` account, add it to the `FEE_MANAGER_CONTRACT_ADDRESSES` map in your dApp's `config.ts` file under the `'solana'` key.
